# api_websockets
An api example for how to use a websocket
